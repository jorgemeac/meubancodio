import java.util.Scanner;

public class Main {
    String nomeCliente;
    String nomeAgencia = "Banco do Brasil";
    int numeroAgencia;
    String numeroConta;
    double saldo = 5000.00;
    Scanner leitor = new Scanner(System.in);


    public static void main(String[] args) {
        Main programa = new Main();
        programa.executar();
    }

    public void executar() {
        System.out.println("Digite o seu nome: ");
        nomeCliente = leitor.nextLine();

        System.out.println("Digite o número de sua agência (Apenas números): ");
        numeroAgencia = leitor.nextInt();
        leitor.nextLine(); // Consumir a quebra de linha pendente

        System.out.println("Digite o número de sua conta (Apenas números): ");
        numeroConta = leitor.nextLine();

        System.out.println("Olá, " + nomeCliente + "! Que bom que acessou sua conta no " + nomeAgencia + ". Sua agência é " + numeroAgencia + ", Conta Corrente " + numeroConta + " e seu saldo é de R$ " + saldo + ".");

        leitor.close(); // Fechar o scanner
    }
}
